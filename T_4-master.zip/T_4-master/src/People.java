public abstract class People {
    String Name;
    String Surname;

    public People(String name, String surname) {
        this.Surname = surname;
        this.Name = name;
    }
}
